
✿ Howdy farmer! ✿


Thank you for purchasing this asset pack, 
I hope you'll enjoy working with it and come back 
for the free updates.

__________________________________

Other assets packs in the making include:
1. Cozy Interior design
2. Player/NPCs (~20px tall)
3. Museum Collection 

｡ﾟ･*☆ﾟ━ ლ(◕˵▽˵◕)ლ ━☆ﾟ.*･｡ﾟ

                        - Shubibubi


