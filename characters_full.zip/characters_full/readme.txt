
Hi there!


Thank you for purchasing Cozy Characters, 
I hope you'll enjoy working with it and come back 
for the free updates.

__________________________________






｡ﾟ･*☆ﾟ━ ლ(◕˵▽˵◕)ლ ━☆ﾟ.*･｡ﾟ

                        - Shubibubi


