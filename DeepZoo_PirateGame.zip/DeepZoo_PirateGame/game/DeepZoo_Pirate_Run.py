import pygame, sys
from pygame.math import Vector2
from random import choice, randint
import pygame
from os import walk
from csv import reader
import imghdr
import os
from math import sin

def import_folder(path):
	surface_list = []

	for _, __, img_files in walk(path): 
		for image in img_files:
			full_path = path + '/' + image
			image_surf = pygame.image.load(full_path).convert_alpha()
			surface_list.append(image_surf)

	return surface_list		

def import_csv_layout(path):
	terrain_map = []
	with open(path) as map:
		level = reader(map,delimiter = ',')
		for row in level:
			terrain_map.append(list(row))
		return terrain_map

def import_cut_graphic(path, tile_width = 64, tile_height = 64):
	surface = pygame.image.load(path).convert_alpha()
	tile_num_x = int(surface.get_size()[0] / tile_width)
	tile_num_y = int(surface.get_size()[1] / tile_height)
	cut_tiles = []

	for row in range(tile_num_y):
		for col in range(tile_num_x):
			x = col * tile_width
			y = row * tile_height
			new_surf = pygame.Surface((tile_width,tile_height),flags = pygame.SRCALPHA)
			new_surf.blit(surface,(0,0),pygame.Rect(x,y,64,64))
			cut_tiles.append(new_surf)
	return cut_tiles

class Tile(pygame.sprite.Sprite):
	def __init__(self,size,x,y):
		super().__init__()
		self.image = pygame.Surface((size,size))
		self.rect = self.image.get_rect(topleft = (x,y))

	def update(self,shift):
		self.rect.x += shift

class StaticTile(Tile):
	def __init__(self,size,x,y,surface):
		super().__init__(size,x,y)
		self.image = surface 

class Crate(StaticTile):
	def __init__(self,size,x,y,surface):
		super().__init__(size,x,y,surface)
		offset_y = y + size
		self.rect = self.image.get_rect(bottomleft = (x,offset_y))

class AnimatedTile(Tile):
	def __init__(self,size,x,y,path):
		super().__init__(size,x,y)
		self.frames = import_folder(path)
		self.frame_index = 0
		self.image = self.frames[self.frame_index]

	def animate(self):
		self.frame_index += 0.15
		if self.frame_index >= len(self.frames):
			self.frame_index = 0
		self.image = self.frames[int(self.frame_index)]

	def update(self,shift):
		self.rect.x += shift
		self.animate()

class Coin(AnimatedTile):
	def __init__(self,size,x,y,value,path):
		super().__init__(size,x,y,path)
		center_x = x + int(size / 2)
		center_y = y + int(size / 2)
		self.rect = self.image.get_rect(center = (center_x,center_y))
		self.value = value

class Palm(AnimatedTile):
	def __init__(self,size,x,y,path,offset):
		super().__init__(size,x,y,path)
		y_offset = y - offset
		self.rect.topleft = (x,y_offset)
    
class Enemy(AnimatedTile):
	def __init__(self,size,x,y,path,speed):
		super().__init__(size,x,y,path)
		self.rect.y += self.rect.height - self.image.get_size()[1]
		self.speed = speed

	def move(self):
		self.rect.x += self.speed

	def reverse(self):
		self.speed *= -1

	def reverse_image(self):
		if self.speed > 0:
			self.image = pygame.transform.flip(self.image,True,False) 

	def update(self,shift):
		self.animate()
		self.move()
		self.reverse_image()
		self.rect.x += shift

class ParticleEffect(pygame.sprite.Sprite):
	def __init__(self,pos,type,speed = 0.5):
		super().__init__()
		if type == 'explosion':
			self.frames = import_folder('../graphics/enemy/explosion')
		if type == 'jump':
			self.frames = import_folder('../graphics/character/dust_particles/jump')
		if type == 'fall':
			self.frames = import_folder('../graphics/character/dust_particles/land')
		self.frame_index = 0
		self.speed = speed
		self.image = self.frames[self.frame_index]
		self.rect = self.image.get_rect(center = pos)

	def animate(self):
		self.frame_index += self.speed
		if self.frame_index >= len(self.frames):
			self.kill()
		else:
			self.image = self.frames[int(self.frame_index)]

	def update(self,shift):
		self.animate()
		self.rect.x += shift    
    
class UI:
	def __init__(self):
		# health 
		self.start = pygame.image.load('../graphics/ui/ui_start.png').convert_alpha()
		self.middle = pygame.image.load('../graphics/ui/ui_middle.png').convert_alpha()
		self.end = pygame.image.load('../graphics/ui/ui_end.png').convert_alpha()
		self.health_bar_color = '#dc4949'
		self.bar_rect_topleft = (54,38)
		self.bar_max_with = 152
		self.bar_height = 4

		# coins
		self.coin_surf = pygame.image.load('../graphics/ui/coin.png').convert_alpha()
		self.coin_rect = self.coin_surf.get_rect(topleft = (50,60))
		self.font = pygame.font.Font('../graphics/ui/ARCADEPI.ttf',30)
		self.font_color = '#33323d'

	def draw_health_bg(self,surface):
		surface.blit(self.start,(20,10))
		surface.blit(self.middle,(84,10))
		surface.blit(self.end,(84 + 64,10))

	def health_bar(self,surface,current,full):
		current_health_ratio = current / full
		current_bar_width = self.bar_max_with * current_health_ratio
		pygame.draw.rect(surface,self.health_bar_color,pygame.Rect(self.bar_rect_topleft,(current_bar_width,self.bar_height)))

	def show_health(self,surface,current,full):
		self.draw_health_bg(surface)
		self.health_bar(surface,current,full)

	def show_coins(self,surface,amount):
		surface.blit(self.coin_surf,self.coin_rect)
		coin_amount_surf = self.font.render(str(amount),False,self.font_color)
		coin_amount_rect = coin_amount_surf.get_rect(midleft = (self.coin_rect.right + 4,self.coin_rect.centery))
		surface.blit(coin_amount_surf,coin_amount_rect)

class Level:
	def __init__(self,level_data,surface,pos_index,load_map,tile_size = 64):
		self.tile_size = tile_size
		self.world_shift = 0
		self.current_x = None
		self.screen_width = screen_width
		self.screen_height = screen_height
		self.main_surface = surface
		
		# player setup
		player_layout = import_csv_layout(level_data['player'])
		self.player = pygame.sprite.GroupSingle()
		self.goal = pygame.sprite.GroupSingle()
		self.player_setup(player_layout)
		self.ui = UI()
		
		# dust 
		self.dust_sprite = pygame.sprite.GroupSingle()
		self.player_on_ground = False
		self.get_player_on_ground()

		# overworld connection
		self.pos_index = pos_index
		self.unlock_id = level_data['unlock']
		self.load_map = load_map

		# audio setup
		self.music = pygame.mixer.Sound('../audio/level_music.wav')
		self.music.play(loops = -1)


		self.stomp_sound = pygame.mixer.Sound('../audio/effects/stomp.wav')
		self.coin_sound = pygame.mixer.Sound('../audio/effects/coin.wav')

		# terrain setup
		terrain_layout = import_csv_layout(level_data['terrain'])
		self.terrain_sprites = self.create_tile_group(terrain_layout,'terrain')
		
		# objects setup 
		fg_palm_layout = import_csv_layout(level_data['fg palms'])
		self.fg_palm_sprites = self.create_tile_group(fg_palm_layout,'fg palms')
		
		# bg palm setup
		bg_palm_layout = import_csv_layout(level_data['bg palms'])
		self.bg_palm_sprites = self.create_tile_group(bg_palm_layout,'bg palms')

		# crate setup
		crate_layout = import_csv_layout(level_data['crates'])
		self.crate_sprites = self.create_tile_group(crate_layout,'crates')

		# coin setup
		coin_layout = import_csv_layout(level_data['coins'])
		self.coin_sprites = self.create_tile_group(coin_layout,'coins')

		# grass setup
		grass_layout = import_csv_layout(level_data['grass'])
		self.grass_sprites = self.create_tile_group(grass_layout,'grass')

		# enemy setup
		enemy_layout = import_csv_layout(level_data['enemies'])
		self.enemy_sprites = self.create_tile_group(enemy_layout,'enemies')
		self.particle_explosion = pygame.sprite.Group()

		# constraint 
		constraint_layout = import_csv_layout(level_data['constraints'])
		self.constraint_sprites = self.create_tile_group(constraint_layout,'constraints')

		# decoration
		self.sky = Sky(8)
		level_width = len(terrain_layout[0]) * tile_size
		self.water = Water(680,level_width)
		self.clouds = Clouds(500,20,level_width)

	def create_tile_group(self,layout,type):
		sprite_group = pygame.sprite.Group()

		for row_index, row in enumerate(layout):
			for col_index, cell in enumerate(row):
				if cell != '-1':
					x = col_index * self.tile_size
					y = row_index * self.tile_size

					if type == 'terrain':
						terrain_graphic_list = import_cut_graphic('../graphics/terrain/terrain_tiles.png')
						surface = terrain_graphic_list[int(cell)]
						sprite = StaticTile(self.tile_size,x,y,surface)	
					
					if type == 'coins':
						if cell == '0': 
							sprite = Coin(self.tile_size,x,y,5,'../graphics/coins/gold')
						elif cell == '1': 
							sprite = Coin(self.tile_size,x,y,1,'../graphics/coins/silver') 
					
					if type == 'fg palms':
						if cell == '1':
							sprite = Palm(self.tile_size,x,y,'../graphics/terrain/palm_small',38)
						if cell == '2':
							sprite = Palm(self.tile_size,x,y,'../graphics/terrain/palm_large',64)
					
					if type == 'bg palms':
						sprite = Palm(self.tile_size,x,y,'../graphics/terrain/palm_bg',64)
					if type == 'crates':		
						surface = pygame.image.load('../graphics/terrain/crate.png').convert_alpha()
						sprite = Crate(self.tile_size,x,y,surface)

					if type == 'enemies':
						sprite = Enemy(self.tile_size, x, y, '../graphics/enemy/run',randint(3,5))
					if type == 'constraints': 
						sprite = Tile(self.tile_size,x,y)

					if type == 'grass':
						grass_surface_list = import_cut_graphic('../graphics/decoration/grass/grass.png')
						surface = grass_surface_list[int(cell)]
						sprite = StaticTile(self.tile_size,x,y,surface)
					
					sprite_group.add(sprite)

		return sprite_group

	def enemy_collision_reverse(self):
		for enemy in self.enemy_sprites.sprites():
			if pygame.sprite.spritecollide(enemy,self.constraint_sprites, False):
				enemy.reverse()

	def player_setup(self,layout):
		for row_index, row in enumerate(layout):
			for col_index, cell in enumerate(row):
				if cell == '0':
					x = col_index * self.tile_size
					y = row_index * self.tile_size
					sprite = Player((x,y),100,self.main_surface,self.create_jump_dust)
					self.player.add(sprite)
				if cell == '1':
					x = col_index * self.tile_size
					y = row_index * self.tile_size
					surface = pygame.image.load('../graphics/character/hat.png').convert_alpha()
					sprite = StaticTile(10,x,y,surface)
					self.goal.add(sprite)

	def player_collision_x(self):
		player = self.player.sprite
		player.rect.x += player.direction.x * player.speed
		collision_sprites = self.terrain_sprites.sprites() + self.crate_sprites.sprites() + self.fg_palm_sprites.sprites()
		for sprite in collision_sprites:
			if sprite.rect.colliderect(player.rect):
				if player.direction.x < 0:
					player.rect.left = sprite.rect.right
					player.on_left = True
					self.current_x = player.rect.left
				elif player.direction.x > 0:
					player.rect.right = sprite.rect.left
					player.on_right = True
					self.current_x = player.rect.right

		if player.on_left and (player.rect.left < self.current_x or player.direction.x >= 0) :
			player.on_left = False
		if player.on_right and (player.rect.right > self.current_x or player.direction.x <= 0):
			player.on_right = False

	def player_collision_y(self):
		player = self.player.sprite
		
		player.apply_gravity()
		player.rect.y += player.direction.y

		collision_sprites = self.terrain_sprites.sprites() + self.crate_sprites.sprites() + self.fg_palm_sprites.sprites()
		for sprite in collision_sprites:
			if sprite.rect.colliderect(player.rect):
				if player.direction.y >= 0:
					player.on_ground = True
					player.rect.bottom = sprite.rect.top
					player.direction.y = 0
				elif player.direction.y < 0:
					player.rect.top = sprite.rect.bottom
					player.direction.y = 0
					player.on_ceiling = True
		
		if player.on_ground and player.direction.y < 0 or player.direction.y > 1:
			player.on_ground = False
		if player.on_ceiling and player.direction.y > 0.1:
			player.on_ceiling = False

	def create_jump_dust(self,pos):
		if self.player.sprite.facing_right:
			pos -= pygame.math.Vector2(10,5)
		else:
			pos += pygame.math.Vector2(10,-5)
		jump_dust_sprite = ParticleEffect(pos,'jump')
		self.dust_sprite.add(jump_dust_sprite)

	def get_player_on_ground(self):
		if self.player.sprite.on_ground:
			self.player_on_ground = True
		else:
			self.player_on_ground = False

	def create_land_dust(self):
		if not self.player_on_ground and self.player.sprite.on_ground and not self.dust_sprite.sprites():
			if self.player.sprite.facing_right: 
				offset = pygame.math.Vector2(10,15)
			else: 
				offset = pygame.math.Vector2(-10,15)
			fall_dust_sprite = ParticleEffect(self.player.sprite.rect.midbottom - offset,'fall')
			self.dust_sprite.add(fall_dust_sprite)

	def level_scroll_x(self):
		player = self.player.sprite
		player_x = player.rect.centerx
		direction_x = player.direction.x

		if player_x < self.screen_width / 4 and direction_x < 0:
			self.world_shift = 8
			player.speed = 0
		elif player_x > self.screen_width - (self.screen_width / 3) and direction_x > 0:
			self.world_shift = -8
			player.speed = 0
		else:
			player.speed = 8
			self.world_shift = 0

	def check_death(self):
		player_y = self.player.sprite.rect.top
		if player_y > self.screen_height + 50:
			self.load_map(self.pos_index,0)
			self.music.stop()
		if self.player.sprite.current_health <= 0:
			self.load_map(self.pos_index,0)
			self.music.stop()

	def win_level(self):
		if pygame.sprite.spritecollide(self.player.sprite,self.goal,True):
			self.load_map(self.pos_index,self.unlock_id)
			self.music.stop()

	def check_player_collision(self):
		enemy_collisions = pygame.sprite.spritecollide(self.player.sprite,self.enemy_sprites,False)

		if enemy_collisions:
			for enemy in enemy_collisions:
				if enemy.rect.top - 8 <= self.player.sprite.rect.bottom <= enemy.rect.top + 12 and self.player.sprite.direction.y > 0:
					self.stomp_sound.play()
					self.player.sprite.direction.y = -15
					explosion_sprite = ParticleEffect(enemy.rect.center,'explosion',0.5)
					self.particle_explosion.add(explosion_sprite)
					enemy.kill()

				else:
					if enemy.rect.centerx > self.player.sprite.rect.centerx:
						self.player.sprite.get_damage(10)
					else:
						self.player.sprite.get_damage(10)

	def check_coin_collisions(self):
		collided_coins = pygame.sprite.spritecollide(self.player.sprite,self.coin_sprites,True)
		if collided_coins:
			self.coin_sound.play()
			for coin in collided_coins:
				self.player.sprite.coins += coin.value

	def run(self):
		self.sky.draw(self.main_surface)
		self.clouds.draw(self.main_surface,self.world_shift)

		self.grass_sprites.update(self.world_shift)
		self.grass_sprites.draw(self.main_surface)

		self.bg_palm_sprites.update(self.world_shift)
		self.bg_palm_sprites.draw(self.main_surface)

		self.dust_sprite.update(self.world_shift)
		self.dust_sprite.draw(self.main_surface)

		self.crate_sprites.update(self.world_shift)
		self.crate_sprites.draw(self.main_surface)

		self.enemy_sprites.update(self.world_shift)
		self.constraint_sprites.update(self.world_shift)
		self.enemy_sprites.draw(self.main_surface)
		self.enemy_collision_reverse()
		
		self.terrain_sprites.update(self.world_shift)
		self.terrain_sprites.draw(self.main_surface)
	
		self.coin_sprites.update(self.world_shift)	
		self.coin_sprites.draw(self.main_surface)

		self.fg_palm_sprites.update(self.world_shift)
		self.fg_palm_sprites.draw(self.main_surface)

		self.particle_explosion.update(self.world_shift)
		self.particle_explosion.draw(self.main_surface)

		self.player.update()
		self.player_collision_x()
		self.get_player_on_ground()
		self.player_collision_y()
		self.create_land_dust()
		self.level_scroll_x()
		self.player.draw(self.main_surface)
		
		self.ui.show_health(self.main_surface,self.player.sprite.current_health,self.player.sprite.max_health)
		self.ui.show_coins(self.main_surface,self.player.sprite.coins)
		self.check_coin_collisions()

		self.check_death()
		self.win_level()
		self.goal.update(self.world_shift)
		self.goal.draw(self.main_surface)
		self.check_player_collision()

		self.water.draw(self.main_surface,self.world_shift)

level_0 = {
		'terrain': '../levels/0/0_terrain.csv',
		'coins':'../levels/0/0_coins.csv',
		'fg palms':'../levels/0/0_fg palms.csv',
		'bg palms':'../levels/0/0_bg palms.csv',
		'crates': '../levels/0/0_crates.csv',
		'enemies':'../levels/0/0_enemies.csv',
		'constraints':'../levels/0/0_constraint.csv',
		'player': '../levels/0/0_player.csv',
		'grass': '../levels/0/0_grass.csv',
		'node': ((110,400),'../graphics/overworld/1'),
		'unlock': 1}
level_1 = {
		'terrain': '../levels/1/1_terrain.csv',
		'coins':'../levels/1/1_coins.csv',
		'fg palms':'../levels/1/1_fg palms.csv',
		'bg palms':'../levels/1/1_bg palms.csv',
		'crates': '../levels/1/1_crates.csv',
		'enemies':'../levels/1/1_enemies.csv',
		'constraints':'../levels/1/1_constraint.csv',
		'player': '../levels/1/1_player.csv',
		'grass': '../levels/1/1_grass.csv',
		'node': ((300,220),'../graphics/overworld/2'),
		'unlock': 2}
level_2 = {
		'terrain': '../levels/1/1_terrain.csv',
		'coins':'../levels/1/1_coins.csv',
		'fg palms':'../levels/1/1_fg palms.csv',
		'bg palms':'../levels/1/1_bg palms.csv',
		'crates': '../levels/1/1_crates.csv',
		'enemies':'../levels/1/1_enemies.csv',
		'constraints':'../levels/1/1_constraint.csv',
		'player': '../levels/1/1_player.csv',
		'grass': '../levels/1/1_grass.csv',
		'node': ((480,610),'../graphics/overworld/3'),
		'unlock': 3}
level_3 = {
		'terrain': '../levels/1/1_terrain.csv',
		'coins':'../levels/1/1_coins.csv',
		'fg palms':'../levels/1/1_fg palms.csv',
		'bg palms':'../levels/1/1_bg palms.csv',
		'crates': '../levels/1/1_crates.csv',
		'enemies':'../levels/1/1_enemies.csv',
		'constraints':'../levels/1/1_constraint.csv',
		'player': '../levels/1/1_player.csv',
		'grass': '../levels/1/1_grass.csv',
		'node': ((610,350),'../graphics/overworld/4'),
		'unlock': 4}
level_4 = {
		'terrain': '../levels/1/1_terrain.csv',
		'coins':'../levels/1/1_coins.csv',
		'fg palms':'../levels/1/1_fg palms.csv',
		'bg palms':'../levels/1/1_bg palms.csv',
		'crates': '../levels/1/1_crates.csv',
		'enemies':'../levels/1/1_enemies.csv',
		'constraints':'../levels/1/1_constraint.csv',
		'player': '../levels/1/1_player.csv',
		'grass': '../levels/1/1_grass.csv',
		'node': ((880,210),'../graphics/overworld/5'),
		'unlock': 5}
level_5 = {
		'terrain': '../levels/1/1_terrain.csv',
		'coins':'../levels/1/1_coins.csv',
		'fg palms':'../levels/1/1_fg palms.csv',
		'bg palms':'../levels/1/1_bg palms.csv',
		'crates': '../levels/1/1_crates.csv',
		'enemies':'../levels/1/1_enemies.csv',
		'constraints':'../levels/1/1_constraint.csv',
		'player': '../levels/1/1_player.csv',
		'grass': '../levels/1/1_grass.csv',
		'node': ((1050,400),'../graphics/overworld/6'),
		'unlock': 5}

levels = {
	0: level_0,
	1: level_1,
	2: level_2,
	3: level_3,
	4: level_4,
	5: level_5}


vertical_tile_num = 11
tile_size = 64

screen_width = 1200
screen_height = vertical_tile_num * tile_size

class Sky:
	def __init__(self,horizon):
		self.top = pygame.image.load('../graphics/decoration/sky/sky_top.png').convert()
		self.bottom = pygame.image.load('../graphics/decoration/sky/sky_bottom.png').convert()
		self.middle = pygame.image.load('../graphics/decoration/sky/sky_middle.png').convert()

		self.tile_h = self.top.get_size()[1]
		self.total_y_tiles = int(screen_height / self.tile_h)
		self.horizon_line = horizon

		# Stretch 
		self.top = pygame.transform.scale(self.top,(screen_width,self.tile_h))
		self.bottom = pygame.transform.scale(self.bottom,(screen_width,self.tile_h))
		self.middle = pygame.transform.scale(self.middle,(screen_width,self.tile_h))
		
	def draw(self,surface):
		for row in range(self.total_y_tiles):
			y = row * self.tile_h
			if row < self.horizon_line: 
				surface.blit(self.top,(0,y))
			elif row == self.horizon_line: 
				surface.blit(self.middle,(0,y))
			else:
				surface.blit(self.bottom,(0,y))

class Water:
	def __init__(self,top,level_width):
		water_start = -screen_width
		water_tile_width = 192 
		tile_x_amount = int(((level_width + 400) - water_start) / water_tile_width)
		self.water_sprites = pygame.sprite.Group()
		
		for tile in range(tile_x_amount):
			x = tile * water_tile_width + water_start
			y = top
			sprite = AnimatedTile(192,x,y,'../graphics/decoration/water')
			self.water_sprites.add(sprite)

	def draw(self,surface,shift):
		self.water_sprites.update(shift)
		self.water_sprites.draw(surface)

class Clouds:
	def __init__(self,horizon,cloud_number,level_width):
		cloud_surf_list = import_folder('../graphics/decoration/clouds')
		min_x = -200
		max_x = level_width
		min_y = 0
		max_y = horizon
		self.cloud_sprites = pygame.sprite.Group()

		for cloud in range(cloud_number):
			cloud = choice(cloud_surf_list)
			x = randint(min_x,max_x)
			y = randint(min_y,max_y)
			sprite = StaticTile(0,x,y,cloud)
			self.cloud_sprites.add(sprite)


	def draw(self,surface,shift):
		self.cloud_sprites.update(shift)
		self.cloud_sprites.draw(surface)

class Node(pygame.sprite.Sprite):
	def __init__(self,pos,path):
		super().__init__()
		self.pos = pos 
		self.frames = import_folder(path)
		self.frame_index = 0
		self.image = self.frames[self.frame_index]
		self.rect = self.image.get_rect(center = pos)

		self.detection_zone = pygame.Rect(pos[0] - 2,pos[1] - 2,8,8)

	def animate(self):
		self.frame_index += 0.2
		if self.frame_index >= len(self.frames):
			self.frame_index = 0
		self.image = self.frames[int(self.frame_index)]

	def update(self,status):
		if status == 'available':
			self.animate()
		else:
			tint_surf = self.image.copy()
			tint_surf.fill((0,0,0),None,pygame.BLEND_RGBA_MULT)
			self.image.blit(tint_surf,(0,0))

class OverWorld:
	def __init__(self,nodes,start_id,load_level,max_level,surface):
		self.nodes = pygame.sprite.Group()
		for node in nodes: 
			node_sprite = Node(node[0],node[1])
			self.nodes.add(node_sprite)
		
		self.bg = BG(surface,12,6)

		self.current_id = start_id
		self.moving = False
		self.move_direction = Vector2(0,0)
		self.speed = 6
		self.max_level = max_level
		self.load_level = load_level
		self.surface = surface	

		# icon graphics
		self.icon_pos = self.nodes.sprites()[self.current_id].pos
		self.y_offset = 30
		self.icon_surf = pygame.image.load('../graphics/overworld/hat.png').convert_alpha()
		self.icon_rect = self.icon_surf.get_rect(midbottom = (self.icon_pos[0],self.icon_pos[1] - self.y_offset))	

		# audio setup
		self.music = pygame.mixer.Sound('../audio/overworld_music.wav')
		self.music.play(loops = -1)

	def draw_nodes(self):
		for index, node in enumerate(self.nodes.sprites()):
			if index <= self.max_level:	
				node.update('available')
			else:
				node.update('locked')
		self.nodes.draw(self.surface)

	def draw_path(self):
		if self.max_level > 0:
			points = [node.pos for index, node in enumerate(self.nodes) if index <= self.max_level]
			pygame.draw.lines(self.surface,'#a04f45',False,points,5)

	def draw_icon(self):
		x = self.icon_pos[0]
		y = self.icon_pos[1] - self.y_offset
		self.icon_rect.center = (x,y)
		self.surface.blit(self.icon_surf,self.icon_rect)
		#pygame.draw.circle(screen,'#F24B59',self.icon_pos,12)

	def update_icon_pos(self):
		if self.moving and self.move_direction:
			self.icon_pos += self.move_direction * self.speed
			target_node = self.nodes.sprites()[self.current_id]
			if target_node.detection_zone.collidepoint(self.icon_pos):
				self.moving = False
				self.move_direction = Vector2(0,0)
		else:
			self.icon_pos = self.nodes.sprites()[self.current_id].pos

	def get_movement_data(self,target):
		start = Vector2(self.nodes.sprites()[self.current_id].pos)

		if target == 'next':
			end = Vector2(self.nodes.sprites()[self.current_id + 1].pos)
		else:
			end = Vector2(self.nodes.sprites()[self.current_id - 1].pos)

		return (end - start).normalize()

	def get_input(self):
		keys = pygame.key.get_pressed()

		if not self.moving:
			if keys[pygame.K_RIGHT] and self.current_id < len(self.nodes) - 1 and self.current_id < self.max_level:
				self.move_direction = self.get_movement_data('next')
				self.current_id += 1
				self.moving = True
			elif keys[pygame.K_LEFT] and self.current_id > 0: 
				self.move_direction = self.get_movement_data('previous')
				self.current_id -= 1
				self.moving = True
			elif keys[pygame.K_SPACE]:
				self.load_level(levels[self.current_id],self.current_id)
				self.music.stop()

	def run(self):
		self.bg.draw()
		self.get_input()
		self.update_icon_pos()
		self.draw_path()
		self.draw_nodes()
		self.draw_icon()

class BG:
	def __init__(self,surface,palm_num,cloud_num):
		self.surface = surface
		self.sky = Sky(8)

		self.horizon = screen_width / 2

		palm_surfaces = import_folder('../graphics/overworld/palms')
		self.random_palms = [choice(palm_surfaces) for path in range(palm_num)]
		self.palm_rects = []
		for surface in self.random_palms:
			x = randint(0,self.surface.get_size()[0])
			y = self.horizon + randint(0,100)
			rect = surface.get_rect(midbottom = (x,y))
			self.palm_rects.append(rect)

		cloud_surfaces = import_folder('../graphics/overworld/clouds')
		self.random_clouds = [choice(cloud_surfaces) for path in range(cloud_num)]
		self.cloud_rects = []
		for surface in self.random_clouds:
			x = randint(0,self.surface.get_size()[0])
			y = randint(0,int(self.horizon - 50))
			rect = surface.get_rect(midbottom = (x,y))
			self.cloud_rects.append(rect)

	def draw_palms(self):
		for index in range(len(self.random_palms)):
			self.surface.blit(self.random_palms[index],self.palm_rects[index])

	def draw_clouds(self):
		for index in range(len(self.random_clouds)):
			self.surface.blit(self.random_clouds[index],self.cloud_rects[index])

	def draw(self):
		self.surface.fill('#ddc6a1')
		self.sky.draw(self.surface)
		self.draw_palms()
		self.draw_clouds()

class Player(pygame.sprite.Sprite):
	def __init__(self,pos,health,surface,create_jump_dust):
		super().__init__()
		# setup
		self.import_main_assets()
		self.frame_index = 0
		self.animation_speed = 0.15
		self.image = self.animations['idle'][self.frame_index]
		self.rect = self.image.get_rect(center = pos)
		
		# dust particles 
		self.surface = surface
		self.import_dust_particles()
		self.dust_frame_index = 0
		self.create_jump_dust = create_jump_dust

		# movement
		self.direction = pygame.math.Vector2(0,0)
		self.speed = 8
		self.gravity = 0.8
		self.jump_speed = -16
		
		# status information
		self.status = 'idle'
		self.on_ground = False
		self.on_ceiling = False
		self.on_left   = False
		self.on_right  = False
		self.facing_right = False

		# game stats
		self.current_health = health
		self.max_health = health
		self.coins = 10
		self.invincible = False
		self.invincibility_duration = 500
		self.hurt_time = 0

		# audio 
		self.jump_sound = pygame.mixer.Sound('../audio/effects/jump.wav')
		self.jump_sound.set_volume(0.5)
		self.hit_sound = pygame.mixer.Sound('../audio/effects/hit.wav')

		

	def import_main_assets(self):
		character_path = '../graphics/character/'
		self.animations = {'idle': [],'run': [],'jump': [], 'fall': []}

		for animation in self.animations.keys():
			full_path = character_path + animation
			self.animations[animation] =  import_folder(full_path)

	def import_dust_particles(self):
		dust_path = '../graphics/character/dust_particles/'
		self.dust_animations = {'jump':[],'land': [],'run':[]}

		for animation in self.dust_animations.keys():
			full_path = dust_path + animation
			self.dust_animations[animation] = import_folder(full_path)

	def get_input(self):
		keys = pygame.key.get_pressed()

		if keys[pygame.K_RIGHT]: 
			self.direction.x = 1
			self.facing_right = True
		elif keys[pygame.K_LEFT]: 
			self.direction.x = -1
			self.facing_right = False
		else: self.direction.x = 0

		if keys[pygame.K_SPACE] and self.on_ground:
			self.jump_sound.play()
			self.jump()
			self.on_ground = False
			self.create_jump_dust(self.rect.midbottom)

	def jump(self):
		#
		self.direction.y = self.jump_speed

	def apply_gravity(self):
		#
		self.direction.y += self.gravity

	def get_status(self):
		if self.direction.y < 0:
			self.status = 'jump'
		elif self.direction.y > 1:
			self.status = 'fall'
		else: 
			if self.direction.x != 0:
				self.status = 'run'
			else:
				self.status = 'idle'

	def animate(self):
		animation = self.animations[self.status]

		# loop over frame index 
		self.frame_index += self.animation_speed
		if self.frame_index >= len(animation):
			self.frame_index = 0
		
		# set the image 
		image = animation[int(self.frame_index)]
		if self.facing_right: 
			self.image = image
		else: 
			flipped_image = pygame.transform.flip(image,True,False)
			self.image = flipped_image

		if self.invincible:
			alpha = self.sine_value()
			self.image.set_alpha(alpha)
		else:
			self.image.set_alpha(255)

		# set the rect 
		if self.on_ground and self.on_right:
			self.rect = self.image.get_rect(bottomright = self.rect.bottomright)
		elif self.on_ground and self.on_left:
			self.rect = self.image.get_rect(bottomleft = self.rect.bottomleft)
		elif self.on_ground:
			self.rect = self.image.get_rect(midbottom = self.rect.midbottom)
		elif self.on_ceiling and self.on_right:
			self.rect = self.image.get_rect(topright = self.rect.topright)
		elif self.on_ceiling and self.on_left:
			self.rect = self.image.get_rect(topleft = self.rect.topleft)
		elif self.on_ceiling:
			self.rect = self.image.get_rect(midtop = self.rect.midtop)

	def dust_animation(self):
		if self.status == 'run' and self.on_ground:
			animation = self.dust_animations['run']
			self.dust_frame_index += self.animation_speed
			if self.dust_frame_index >= len(animation):
				self.dust_frame_index = 0
			dust_particle = animation[int(self.dust_frame_index)]
			if self.facing_right:
				self.surface.blit(dust_particle,self.rect.bottomleft - pygame.math.Vector2(6,10))
			else:
				dust_particle = pygame.transform.flip(dust_particle,True,False)
				self.surface.blit(dust_particle,self.rect.bottomright - pygame.math.Vector2(6,10))

	def sine_value(self):
		val = int(sin(pygame.time.get_ticks()) * 2)
		if val < 0: val = 0
		return val * 100

	def get_damage(self,amount):
		if not self.invincible:
			self.hit_sound.play()
			self.current_health -= amount
			self.invincible = True
			self.hurt_time = pygame.time.get_ticks()

	def invincibility_timer(self):
		if self.invincible:
			current_time = pygame.time.get_ticks()
			if current_time - self.hurt_time >= self.invincibility_duration:
				self.invincible = False

	def update(self):
		self.get_input()
		self.get_status()
		self.animate()
		self.dust_animation()
		self.invincibility_timer()

class Game:
	def __init__(self,game_data):
		self.max_level = 5
		self.get_nodes(game_data)
		self.overworld = OverWorld(self.nodes,0,self.load_level,self.max_level,screen)
		self.status = 'overworld'

	def get_nodes(self,levels):
		self.nodes = []
		for level in levels.values():
			self.nodes.append(level['node'])

	def load_level(self,level_data,pos_index):
		self.level = Level(level_data,screen,pos_index,self.load_map) 
		self.status = 'level'

	def load_map(self,pos_index,new_max):
		if new_max >= self.max_level: self.max_level = new_max
		self.overworld = OverWorld(self.nodes,pos_index,self.load_level,self.max_level,screen)
		self.status = 'overworld'

	def run(self):
		if self.status == 'overworld':
			self.overworld.run()
		elif self.status == 'level':
			self.level.run()

if __name__ == '__main__':
	pygame.init()
	screen = pygame.display.set_mode((screen_width,screen_height))
	clock = pygame.time.Clock()
	game = Game(levels)

	while True:
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				sys.exit()
		
		game.run()
		pygame.display.update()
		clock.tick(60)
